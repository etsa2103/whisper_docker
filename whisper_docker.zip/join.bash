#!/bin/bash
docker exec -it dtc-jackal-phobos-whisper bash